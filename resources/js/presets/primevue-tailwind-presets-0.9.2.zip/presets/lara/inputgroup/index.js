export default {
    root: {
        class: ['flex items-stretch', 'w-full']
    }
};
